package com.google.name.framework.presentation.model

enum class Gender {
    MALE, FEMALE, NONE
}