package com.google.name.buisness.domain.model

abstract class NameGender