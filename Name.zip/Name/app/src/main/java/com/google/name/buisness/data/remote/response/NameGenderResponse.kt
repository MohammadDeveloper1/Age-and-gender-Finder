package com.google.name.buisness.data.remote.response

abstract class NameGenderResponse