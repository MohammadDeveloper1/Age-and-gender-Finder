package com.google.name.buisness.domain.model

data class Name(
    var name: String,
    var age: Int,
    var gender: String,
    var country: String?
)