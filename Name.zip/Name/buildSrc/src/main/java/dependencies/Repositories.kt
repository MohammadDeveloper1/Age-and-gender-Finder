package dependencies

object Repositories {
    val fabric = "https://maven.fabric.io/public"
}