package dependencies

object Application {
    val id = "com.google.cleannote"
    val version_code = 1
    val version_name = "1.0"
}