package dependencies

object Java {
    val java_version = "1.8"
}